MANBA — GITHUB PAGES PAKETI

Ushbu papkadagi 4 faylni GitHub repository'ingizning asosiy papkasiga joylang:
- index.html   (asosiy sayt)
- manifest.json (PWA sozlamalari)
- sw.js         (service worker/kesh)
- icon.svg      (ilova belgisi)

Muhim: avval eski index.html faylingizdan zaxira nusxa oling. So'ng ushbu paketdagi
index.html ni repository'dagi index.html bilan almashtiring va qolgan 3 faylni
ham shu joyga yuklang. GitHub Pages sozlamasida branch=main va folder=/(root)
bo'lishi kerak.

Ushbu versiyada Three.js CDN orqali yuklanadi, shuning uchun birinchi yuklashda
internet kerak. APK yaratishdan oldin saytni GitHub Pages'da tekshiring.
