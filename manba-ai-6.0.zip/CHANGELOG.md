# Manba AI 5.0

- Cosmic 4.3 asosidagi responsive UI saqlandi.
- O‘qituvchi rejimi qo‘shildi: dars rejasi, topshiriq, rubrika, nazorat savollari, fikr-mulohaza va ota-onaga xabar.
- O‘qituvchi bo‘limi desktop navigatsiya, telefon navigatsiya va bosh sahifadagi tezkor amallarga qo‘shildi.
- AI natijasini TXT sifatida yuklab olish qo‘shildi.
- PWA manifest va service worker cache versiyasi 5.0 ga yangilandi.
- GitHub Pages deploy va maxfiylik yo‘riqnomasi yangilandi.

# Manba AI 6.0

- Ish stoli (desktop): chap tomonda vertikal navigatsiya, binafsha gradient faol tab.
- Yangi dizayn qatlami design-6.css; app.js va ID’lar o‘zgarmadi.
- Service worker cache 6.0 ga yangilandi.
- O‘qituvchi rejimi chap menyuga qo‘shildi; bosh sahifaga funksiyalar kartalari va kalendar vidjeti qo‘shildi (extras-6.js).
- PDF bilan chat (tanlangan hujjat bo‘yicha), rasm tahlili (OCR, tavsif, grafik, masala) va ovozdan matn/matndan ovoz qo‘shildi (ai-tools-6.js).
- Worker rasm qabul qiladi va rasm bo‘lsa vision modelga yo‘naltiradi.
