# Manba AI 5.0 — Cosmic Education

O‘zbek tilidagi responsive, kosmik dizaynli ta’lim PWA. Talaba va o‘qituvchi uchun bir sahifali ilova.

## ZIP tarkibi
- `index.html`, `styles.css`, `app.js`, `orbit.js` — interfeys va funksiyalar
- `earth-texture.jpg`, `moon-texture.jpg` — kosmik fon teksturalari
- `sw.js`, `manifest.json`, `icon.svg` — PWA
- `worker.js` — ixtiyoriy Cloudflare Worker AI proxy
- `design-preview.png` — dizayn konsepsiyasi (referens, ilovaning o‘zida fon sifatida ishlatilmaydi)

## Talabalar funksiyalari
- AI ustoz / manba asosida savol-javob
- PDF va DOCX yuklash
- Test va flashkartalar
- Referat/konspekt va slayd rejalari
- Maqsadlar: kunlik, doimiy, muddatli
- Pomodoro, o‘quv statistikasi, kalendar-reja

## O‘qituvchi rejimi (5.0)
- Dars rejasi generatori
- Topshiriqlar tayyorlash
- Baholash rubrikasi
- Nazorat savollari
- O‘quvchi fikr-mulohazasi shablonlari
- Ota-onaga xabar shabloni

O‘qituvchi generatorlari AI provayderiga ulanganida ishlaydi. API sozlamalari: **Sozlamalar → AI provayder**.

## GitHub Pages’ga joylash
1. ZIP’ni kompyuter/telefoningizda **extract** qiling.
2. ZIP ichidagi barcha fayllarni repository root’iga yuklang. `index.html` root ichida ko‘rinishi shart. ZIP yoki ichki papkani o‘zini yuklamang.
3. GitHub → Settings → Pages → Deploy from branch → `main` → `/(root)` tanlang (repository sozlamangizga mos branchni tanlang).
4. Deploy muvaffaqiyatli bo‘lgach, Pages bergan URL’ni oching.
5. Avval inkognito/private tab’da tekshiring. Eski versiya chiqsa, site cache/service worker ma’lumotlarini tozalang.

## Mahalliy sinov
HTTP server orqali oching (file:// emas):
```bash
python -m http.server 8000
```
So‘ng `http://localhost:8000/` ni oching.

## Muhim cheklovlar va maxfiylik
- Bu statik PWA; login, server bazasi va haqiqiy billing yo‘q. Free/Pro tanlovi demo/mahalliy rejim.
- AI funksiyalari uchun foydalanuvchi o‘z API kalitini kiritishi yoki Worker URL sozlashi kerak. API kalitni brauzerda saqlash qurilma/brauzerga kirish imkoniga ega odamdan himoya qilmaydi; maxfiy kalit uchun Worker proxy xavfsizroq.
- AI ishlaganda prompt va tanlangan manba parchasi AI provayderiga yuboriladi. Maxfiy hujjatlarni yuborishdan oldin buni hisobga oling.
- PDF/DOCX parserlari CDN orqali yuklanadi, shu sabab birinchi ishga tushishda internet talab qilinishi mumkin.
- PPTX/PDF eksport to‘liq hujjat dizayni sifatida hali qo‘shilmagan; slayd/referat matnini TXT sifatida yuklab olish mavjud.

## Tekshiruv holati
Build uchun JS sintaksis tekshiruvi, HTML ID takrorlanmasligi, lokal asset manzillari va ZIP integrity tekshiriladi. Bu muhitda GitHub Pages deploy yoki real brauzerda tashqi AI provider bilan end-to-end sinov kafolatlanmaydi.
